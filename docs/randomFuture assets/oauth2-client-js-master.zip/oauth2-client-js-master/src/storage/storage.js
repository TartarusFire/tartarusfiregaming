export default class OAuthTokenStorage {
    constructor() {}

    /* eslint-disable */
    get(key) {}
    set(key, val) {}
    remove(key) {}
    _empty() {}
    _purge() {}
    /* eslint-enable */
}