#!/bin/bash

npm test
webpack
npm publish .