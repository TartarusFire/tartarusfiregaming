#!/bin/bash

webpack && npm publish .