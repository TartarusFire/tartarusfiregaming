module.exports = function() {
  return "this is module2";
};
