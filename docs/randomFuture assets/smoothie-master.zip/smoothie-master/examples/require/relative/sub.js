'use strict';

exports.greet = function() {
  return 'Hello from sub!';
}
